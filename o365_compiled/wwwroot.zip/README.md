# o365_functions
Slackbot to interact with Office 365

Check `Readme.md` in each Function's directory for more information.
